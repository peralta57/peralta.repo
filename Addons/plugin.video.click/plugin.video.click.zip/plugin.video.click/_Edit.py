import xbmcaddon

MainBase = 'http://peraltabuildwizard.netai.net/click/click.xml'
addon = xbmcaddon.Addon('plugin.video.click')